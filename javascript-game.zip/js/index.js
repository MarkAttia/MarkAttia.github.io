const canvas = document.getElementById('canvas');
const ctx = canvas.getContext("2d");

function setupCanvas() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  ctx.font = "15px Arial";
  ctx.lineJoin = 'round';
  ctx.lineCap = "round";
}

setupCanvas();
window.onresize = function() {
  setupCanvas();
};